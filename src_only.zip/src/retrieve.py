from pathlib import Path
import json
import pickle
from typing import List, Dict

import faiss
import numpy as np
from rank_bm25 import BM25Okapi
from fastembed import TextEmbedding


ROOT_DIR = Path(__file__).resolve().parents[1]

INDEX_DIR = ROOT_DIR / "indexes"
FAISS_PATH = INDEX_DIR / "faiss.index"
BM25_PATH = INDEX_DIR / "bm25.pkl"
METADATA_PATH = INDEX_DIR / "metadata.json"

EMBEDDING_MODEL_NAME = "BAAI/bge-small-en-v1.5"

BM25_TOP_K = 50
DENSE_TOP_K = 50
FINAL_TOP_K = 10


def tokenize(text: str) -> list[str]:
    return text.lower().split()


def normalize_vector(vector: np.ndarray) -> np.ndarray:
    norm = np.linalg.norm(vector)
    if norm == 0:
        return vector
    return vector / norm


def load_indexes():
    if not FAISS_PATH.exists():
        raise FileNotFoundError("FAISS index not found. Run: python src/build_index.py")

    if not BM25_PATH.exists():
        raise FileNotFoundError("BM25 index not found. Run: python src/build_index.py")

    if not METADATA_PATH.exists():
        raise FileNotFoundError("metadata.json not found. Run: python src/build_index.py")

    faiss_index = faiss.read_index(str(FAISS_PATH))

    with BM25_PATH.open("rb") as f:
        bm25_index = pickle.load(f)

    with METADATA_PATH.open("r", encoding="utf-8") as f:
        chunks = json.load(f)

    return faiss_index, bm25_index, chunks


def bm25_search(query: str, bm25_index: BM25Okapi, chunks: List[Dict], top_k: int) -> List[Dict]:
    scores = bm25_index.get_scores(tokenize(query))
    top_indices = np.argsort(scores)[::-1][:top_k]

    results = []

    for idx in top_indices:
        chunk = chunks[int(idx)].copy()
        chunk["bm25_score"] = float(scores[idx])
        chunk["dense_score"] = 0.0
        chunk["retrieval_source"] = "bm25"
        results.append(chunk)

    return results


def dense_search(query: str, faiss_index, chunks: List[Dict], model: TextEmbedding, top_k: int) -> List[Dict]:
    query_embedding = list(model.embed([query]))[0]
    query_embedding = np.array(query_embedding, dtype="float32")
    query_embedding = normalize_vector(query_embedding)
    query_embedding = np.expand_dims(query_embedding, axis=0)

    scores, indices = faiss_index.search(query_embedding, top_k)

    results = []

    for score, idx in zip(scores[0], indices[0]):
        if idx == -1:
            continue

        chunk = chunks[int(idx)].copy()
        chunk["dense_score"] = float(score)
        chunk["bm25_score"] = 0.0
        chunk["retrieval_source"] = "dense"
        results.append(chunk)

    return results


def merge_results(bm25_results: List[Dict], dense_results: List[Dict]) -> List[Dict]:
    merged = {}

    for result in bm25_results + dense_results:
        chunk_id = result["chunk_id"]

        if chunk_id not in merged:
            merged[chunk_id] = result
        else:
            merged[chunk_id]["bm25_score"] = max(
                merged[chunk_id].get("bm25_score", 0.0),
                result.get("bm25_score", 0.0)
            )
            merged[chunk_id]["dense_score"] = max(
                merged[chunk_id].get("dense_score", 0.0),
                result.get("dense_score", 0.0)
            )
            merged[chunk_id]["retrieval_source"] = "hybrid"

    results = list(merged.values())

    for result in results:
        result["hybrid_score"] = result.get("bm25_score", 0.0) + result.get("dense_score", 0.0)

    results.sort(key=lambda x: x["hybrid_score"], reverse=True)

    return results


def retrieve(query: str, final_top_k: int = FINAL_TOP_K) -> List[Dict]:
    faiss_index, bm25_index, chunks = load_indexes()

    print("Loading FastEmbed model...")
    model = TextEmbedding(model_name=EMBEDDING_MODEL_NAME)

    bm25_results = bm25_search(query, bm25_index, chunks, BM25_TOP_K)
    dense_results = dense_search(query, faiss_index, chunks, model, DENSE_TOP_K)

    merged_results = merge_results(bm25_results, dense_results)

    return merged_results[:final_top_k]


def main() -> None:
    query = input("Ask MDR question: ")

    results = retrieve(query)

    print("\nTop retrieved chunks:\n")

    for i, chunk in enumerate(results, start=1):
        print("=" * 80)
        print(f"Result {i}")
        print(f"Chunk ID: {chunk['chunk_id']}")
        print(f"Title: {chunk.get('title')}")
        print(f"Type: {chunk.get('type')}")
        print(f"Pages: {chunk.get('page_start')} - {chunk.get('page_end')}")
        print(f"Hybrid score: {chunk.get('hybrid_score')}")
        print()
        print(chunk["text"][:1000])
        print()


if __name__ == "__main__":
    main()