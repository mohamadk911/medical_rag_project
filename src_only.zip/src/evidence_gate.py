from pathlib import Path
from typing import List, Dict
import os

from dotenv import load_dotenv
from google import genai


ROOT_DIR = Path(__file__).resolve().parents[1]

EVIDENCE_PROMPT_PATH = ROOT_DIR / "prompts" / "evidence_prompt.txt"

GEMINI_MODEL = "gemini-2.5-flash"

INSUFFICIENT_MESSAGE = (
    "I could not find sufficient evidence in the available MDR and MDCG "
    "sources to answer this question."
)


def load_prompt(path: Path) -> str:
    if not path.exists():
        raise FileNotFoundError(f"Prompt file not found: {path}")

    return path.read_text(encoding="utf-8")


def format_context(chunks: List[Dict]) -> str:
    parts = []

    for chunk in chunks:
        parts.append(
            f"""
SOURCE ID: {chunk.get("chunk_id")}
SOURCE TYPE: {chunk.get("source_type", "MDR")}
DOCUMENT: {chunk.get("source", chunk.get("document_title", "Unknown"))}
TITLE: {chunk.get("title")}
TYPE: {chunk.get("type")}
PAGES: {chunk.get("page_start")} - {chunk.get("page_end")}

TEXT:
{chunk.get("text")}
"""
        )

    return "\n\n---\n\n".join(parts)


def get_first_label(text: str) -> str:
    if not text.strip():
        return "INSUFFICIENT_EVIDENCE"

    first_line = text.strip().splitlines()[0].strip().upper()

    if "NEEDS_MORE_DEVICE_INFO" in first_line:
        return "NEEDS_MORE_DEVICE_INFO"

    if "INSUFFICIENT_EVIDENCE" in first_line:
        return "INSUFFICIENT_EVIDENCE"

    if "ANSWERABLE" in first_line:
        return "ANSWERABLE"

    return "INSUFFICIENT_EVIDENCE"


def check_evidence_gate(question: str, retrieved_chunks: List[Dict]) -> Dict:
    if not retrieved_chunks:
        return {
            "passed": False,
            "reason": "insufficient_evidence",
            "message": INSUFFICIENT_MESSAGE,
        }

    load_dotenv()

    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ValueError("Missing GEMINI_API_KEY in .env file")

    client = genai.Client(api_key=api_key)

    evidence_prompt = load_prompt(EVIDENCE_PROMPT_PATH)
    context = format_context(retrieved_chunks)

    full_prompt = f"""
{evidence_prompt}

USER QUESTION:
{question}

RETRIEVED REGULATORY SOURCES:
{context}
"""

    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=full_prompt,
    )

    result_text = (response.text or "").strip()
    label = get_first_label(result_text)

    if label == "ANSWERABLE":
        return {
            "passed": True,
            "reason": "answerable",
            "message": result_text,
        }

    if label == "NEEDS_MORE_DEVICE_INFO":
        return {
            "passed": False,
            "reason": "needs_more_device_info",
            "message": result_text,
        }

    return {
        "passed": False,
        "reason": "insufficient_evidence",
        "message": INSUFFICIENT_MESSAGE + "\n\n" + result_text,
    }